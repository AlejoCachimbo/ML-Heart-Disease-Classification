(c) all rights reserved, 2019-2021 HardTop/HARDTOPnet

You are not allowed to share, redistribute, extract parts or sell back some or all of this pack.


===============================================================================================


This pack was created in part with free textures and assets from the following services:

--- free texture resources

FreePBR : https://freepbr.com
CgBookCase : https://www.cgbookcase.com
CC0Textures : https://cc0textures.com/
3D Textures : https://3dtextures.me/
TextureHaven : https://texturehaven.com/
SubstanceShare : https://share.substance3d.com
texturecan : https://www.texturecan.com/

--- creative common textures

Birch leaves texture - modified version of photo from original author S.Rae under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/

Mahogany fruit texture - modified version of photo from original author James St. John under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/
https://search.creativecommons.org/photos/8c8c46ee-84ed-4320-aec6-510aa8520183
https://www.flickr.com/photos/47445767@N05

Allium flowers texture - modified version of photo from original author Ruth and Dave under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/
https://search.creativecommons.org/photos/5f365b61-1056-4b39-85c8-7ffba18ef841
https://www.flickr.com/photos/95142644@N00

ggallice - Leaf texture - modified version of photo from original author Matanya under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/

Beets texture - modified version of photo from original author Joelk75 under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/
https://search.creativecommons.org/photos/8f5109b4-d670-4248-a7f3-f482440dbd22
https://www.flickr.com/photos/75001512@N00

Bread/cake texture - modified version of photo from original author youngthousands under CC BY 2.0 licence
https://creativecommons.org/licenses/by/2.0/
https://search.creativecommons.org/photos/7a787a2a-e6af-4396-a7e8-41929e442d98
https://www.flickr.com/photos/60991646@N00/2856924221

--- substance utilities

Cracks generator by user Bruno Afonseca			https://share.substance3d.com/libraries/22
EnvironmentToolKit by user Wes McDermott		https://share.substance3d.com/libraries/2042
MultiDirectionalWarp by user Vincent Gault		https://share.substance3d.com/libraries/2728
DeteDirectionalWarp by Art of Daniel Thiger		https://gumroad.com/l/detedirectionalwarp

Filter_BrushEffects 							https://share.substance3d.com/libraries/2817
Filter_EdgeDetection 							https://share.substance3d.com/libraries/3444
Filter_NoiseReduction 							https://share.substance3d.com/libraries/2118
by user suzukiMY 								https://share.substance3d.com/libraries?by_user_id=777

--- substance texture generators

Tree Bark by user Wes McDermott					https://share.substance3d.com/libraries/2748
Redwood Bark by user mauriciochihuahua			https://share.substance3d.com/libraries/3012
Tree Stump by user Zot							https://share.substance3d.com/libraries/4381
Procedural stone texture by user TPVortex		https://share.substance3d.com/libraries/766
Carrots texture by user cypher2012				https://share.substance3d.com/libraries/5467
Golden Angle Fermat Spiral by user somitsu		https://share.substance3d.com/libraries/4116
Brain coral texture by user Nikola Damjanov		https://share.substance3d.com/libraries/5247
Dead coral texture by user Nikola Damjanov 		https://share.substance3d.com/libraries/5250
Dynamic Creature Scales by user Palirano		https://share.substance3d.com/libraries/3373
Synthetic Foam by user amaraklov				https://share.substance3d.com/libraries/2082
Log end by Allegorithmic						https://share.substance3d.com/libraries/1780
Ice Cream by tiffanyChu							https://share.substance3d.com/libraries/990
Strawberry by Claud63 							https://share.substance3d.com/libraries/5581
SP 1 Crab Abdomen by Allegorithmic				https://share.substance3d.com/libraries/1778
SP 1 Paper 005 by Allegorithmic					https://share.substance3d.com/libraries/1761
SP 1 Leather Interior by Allegorithmic			https://share.substance3d.com/libraries/1783
Mushroom by user Russ Bittles 0					https://share.substance3d.com/libraries/4093
Melted candle wax by user simone light			https://share.substance3d.com/libraries/3956
Forest Mud by user Sillmin						https://share.substance3d.com/libraries/890